package com.example.galeriacatalogo

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.usopreferencias.R

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var rvProductos: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar SharedPreferences
        prefs = getSharedPreferences("catalogo_prefs", Context.MODE_PRIVATE)

        // Configurar RecyclerView
        rvProductos = findViewById(R.id.rvProductos)
        rvProductos.layoutManager = LinearLayoutManager(this)

        actualizarLista()

        findViewById<Button>(R.id.btnGuardar).setOnClickListener {
            val n = findViewById<EditText>(R.id.etNombre).text.toString()
            val c = findViewById<EditText>(R.id.etCantidad).text.toString()
            val p = findViewById<EditText>(R.id.etPrecio).text.toString()

            if (n.isNotEmpty() && c.isNotEmpty() && p.isNotEmpty()) {
                val data = prefs.getString("productos", "") ?: ""
                val nuevo = "$n|$c|$p;"
                prefs.edit().putString("productos", data + nuevo).apply() //
                actualizarLista()
                Toast.makeText(this, "Guardado en XML", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun actualizarLista() {
        val raw = prefs.getString("productos", "") ?: ""
        val lista = mutableListOf<Producto>()

        if (raw.isNotEmpty()) {
            raw.split(";").filter { it.contains("|") }.forEach { registro ->
                val parts = registro.split("|")

                // Lógica para asignar la imagen según el nombre del producto
                val nombreProducto = parts[0].lowercase()
                val imagenParaMostrar = when {
                    nombreProducto.contains("laptop") -> R.drawable.ic_laptop
                    nombreProducto.contains("celular") || nombreProducto.contains("phone") -> R.drawable.ic_phone
                    nombreProducto.contains("monitor") || nombreProducto.contains("pantalla") -> R.drawable.ic_monitor
                    else -> R.drawable.ic_laptop // Imagen por defecto si no coincide nada
                }

                // Ahora pasamos los 4 parámetros: nombre, cantidad, precio e imagen
                lista.add(Producto(
                    parts[0],
                    parts[1].toInt(),
                    parts[2].toDouble(),
                    imagenParaMostrar
                ))
            }
        }
        rvProductos.adapter = ProductoAdapter(lista)
    }
}