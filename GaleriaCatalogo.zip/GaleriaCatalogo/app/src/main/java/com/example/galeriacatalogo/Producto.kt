package com.example.galeriacatalogo

data class Producto(
    val nombre: String,
    val cantidad: Int,
    val precio: Double,
    val imagenRes: Int = android.R.drawable.ic_menu_gallery
)