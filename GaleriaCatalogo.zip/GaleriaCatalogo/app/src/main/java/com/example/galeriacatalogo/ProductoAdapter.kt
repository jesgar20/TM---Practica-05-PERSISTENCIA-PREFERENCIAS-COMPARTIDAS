package com.example.galeriacatalogo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

import com.example.usopreferencias.R

class ProductoAdapter(private val productos: List<Producto>) :
    RecyclerView.Adapter<ProductoAdapter.ViewHolder>() {

    class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        val tvNombre: TextView = v.findViewById(R.id.tvNombre)
        val tvDetalle: TextView = v.findViewById(R.id.tvDetalle)
        val imgProducto: ImageView = v.findViewById(R.id.imgProducto) // Vinculación de la imagen
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_producto, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(h: ViewHolder, p: Int) {
        val item = productos[p]
        h.tvNombre.text = item.nombre
        h.tvDetalle.text = "Cant: ${item.cantidad} - Precio: S/ ${item.precio}"

        // Aquí asignamos la imagen.
        // Si no tienes imágenes personalizadas aún, usará el icono por defecto que pusimos en el XML.
        h.imgProducto.setImageResource(item.imagenRes)
    }

    override fun getItemCount() = productos.size
}